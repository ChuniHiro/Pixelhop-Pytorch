"""
# v 2021.04.18
# overlapping max pooling
"""
import numpy as np
from keras.datasets import mnist,fashion_mnist,cifar10
from skimage.util import view_as_windows
from pixelhop import Pixelhop
from skimage.measure import block_reduce
import xgboost as xgb
import warnings, gc
import time
# from memory_profiler import profile
from tensorflow.python.platform import flags
import layer
import pickle
import os
import data

flags.DEFINE_string("AUG","0,1,2,3,4,5,6,7", "augmentation mode")# LAG
flags.DEFINE_integer("train_M1",1, "augmentation mode")# LAG
flags.DEFINE_integer("getoutput_M1",1, "augmentation mode")# LAG
flags.DEFINE_string("imgtype",'P', "augmentation mode")# LAG
flags.DEFINE_integer("BS", 5000, "augmentation mode")# LAG
flags.DEFINE_string("dataset",'cifar', "augmentation mode")# LAG
flags.DEFINE_integer("normalization", 0, "augmentation mode")# LAG

flags.DEFINE_string("saveroot",'/media/bingbing/MyData/ICPR_CIFAR/baseline_result/cwsaab_mnist_0418_AUG_', "save root")# LAG
FLAGS = flags.FLAGS

saveroot = FLAGS.saveroot+'/' 
if not os.path.isdir(saveroot):os.makedirs(saveroot)
BS = FLAGS.BS

def shuffle_data(X,y):
    shuffle_idx = np.random.permutation(y.size)
    X = X[shuffle_idx]
    y = y[shuffle_idx]
    return X, y

def select_balanced_subset(images, labels, use_num_images):
    '''
    select equal number of images from each classes
    '''
    num_total, H, W, C = images.shape
    num_class = np.unique(labels).size
    num_per_class = int(use_num_images/num_class)

    # Shuffle
    images, labels = shuffle_data(images, labels)
    
    selected_images = np.zeros((use_num_images, H, W, C))
    selected_labels = np.zeros(use_num_images)
    
    for i in range(num_class):
        selected_images[i*num_per_class:(i+1)*num_per_class] = images[labels==i][:num_per_class]
        selected_labels[i*num_per_class:(i+1)*num_per_class] = np.ones((num_per_class)) * i

    # Shuffle again
    selected_images, selected_labels = shuffle_data(selected_images, selected_labels)
    
    return selected_images, selected_labels


def Shrink(X, shrinkArg):
    pool = shrinkArg['pool']
    ch = X.shape[-1]
    if pool>1:
        if pool==2:
            X = block_reduce(X, (1, pool, pool, 1), np.max)
        elif pool==3: # overlapping pool
            X = view_as_windows(X, (1,pool,pool,ch), (1,2,2,ch))
            X = X.reshape(X.shape[0],X.shape[1],X.shape[2],pool*pool,-1)
            X = np.max(X,axis=3)
            
    win = shrinkArg['win']
    stride = shrinkArg['stride']
    pad = shrinkArg['pad']
    if pad>0:
        X = np.pad(X,((0,0),(pad,pad),(pad,pad),(0,0)),'reflect')
    X = view_as_windows(X, (1,win,win,ch), (1,stride,stride,ch))
    return X.reshape(X.shape[0], X.shape[1], X.shape[2], -1)

# example callback function for how to concate features from different hops
def Concat(X, concatArg):
    return X
    

def get_feat(X, num_layers=3, output_all=False):
    if output_all == True:
        output = []
        output.append(p2.transform_singleHop(X,layer=0))
    else:
        output = p2.transform_singleHop(X,layer=0)
        
    if num_layers>1:
        for i in range(num_layers-1):
            if output_all == True:
                tmp = p2.transform_singleHop(output[-1], layer=i+1)
                output.append(tmp)
            else:
                output = p2.transform_singleHop(output, layer=i+1)
                
    return output

def save_feat(X, BS=10, mode='tr', saveroot='./', num_layers=4, output_all=True):
    N_Full = X.shape[0]
    if BS>0:
        for i in range(N_Full//BS):
            tmp_output = get_feat(X[i*BS:(i+1)*BS], num_layers=num_layers, output_all=output_all)
            NUM_HOPS = len(tmp_output)
            for k in range(NUM_HOPS):
                with open(saveroot + mode + '_output_stage'+str(k+1)+'_'+str(i)+'.npy', 'wb') as f:
                    np.save(f, tmp_output[k])
                fwrite = open(saveroot+'AUG'+str(len(AUG_list))+'_Hop'+str(k+1)+'_dim'+str(tmp_output[k].shape[-1])+'.pkl','wb')
                pickle.dump([],fwrite)
                fwrite.close()
            del tmp_output

        for k in range(num_layers):
            output = []
            for i in range(N_Full//BS):
                with open(saveroot + mode + '_output_stage'+str(k+1)+'_'+str(i)+'.npy', 'rb') as f:
                    output.append(np.load(f))
                with open(saveroot + mode + '_output_stage'+str(k+1)+'_'+str(i)+'.npy', 'wb') as f:
                    np.save(f, np.array([0]))
            output = np.concatenate(output,axis=0)#.reshape(sample_images.shape[0],-1)
            print(output.shape)
            with open(saveroot + mode + '_feature_Hop'+str(k+1)+'_all_AUG'+str(len(AUG_list))+'.npy', 'wb') as f:
                np.save(f, output)
    else:
        output = get_feat(X, num_layers=num_layers, output_all=output_all)
        NUM_HOPS = len(output)
        for k in range(NUM_HOPS):
            with open(saveroot + mode + '_feature_Hop'+str(k+1)+'_all_AUG'+str(len(AUG_list))+'.npy', 'wb') as f:
                np.save(f, output)
    

if __name__ == "__main__":
    warnings.filterwarnings("ignore")
    '''Load MNIST-10 data and split'''
    if FLAGS.dataset == 'mnist':
        (train_data_ori, train_labels), (test_data_ori, test_labels) = mnist.load_data()
    elif FLAGS.dataset == 'fashion':
        (train_data_ori, train_labels), (test_data_ori, test_labels) = fashion_mnist.load_data()
    elif FLAGS.dataset == 'cifar':
        (train_data_ori, train_labels), (test_data_ori, test_labels) = cifar10.load_data()
        
    # -----------Data Preprocessing-----------
    # train_data_ori = train_data_ori[:,:,:,np.newaxis]
    # test_data_ori = test_data_ori[:,:,:,np.newaxis]

    print(train_labels[:10])
    print(test_labels[:10])
    train_data_ori = train_data_ori.astype('float64')/255.
    test_data_ori = test_data_ori.astype('float64')/255.
    
    
    AUG_list = [int(s) for s in FLAGS.AUG.split(',')]

    if len(AUG_list)>1:    
        train_data_ori = layer.augment_combine(train_data_ori,mode=AUG_list)
        train_data_ori = np.concatenate(train_data_ori,axis=0)
        test_data_ori = layer.augment_combine(test_data_ori,mode=AUG_list)
        test_data_ori = np.concatenate(test_data_ori,axis=0)
        train_data_ori = train_data_ori.astype('float64')
        test_data_ori = test_data_ori.astype('float64')
        
        
    if FLAGS.imgtype != 'RGB':
        if FLAGS.imgtype == 'P' or FLAGS.imgtype == 'Q' or FLAGS.imgtype == 'PQR_R' or FLAGS.imgtype == 'PQR':
            _, color_pca, bias = data.convert_image(train_data_ori[:50000], 'PQR', color_pca=None, bias=None)
            train_data, _,_ = data.convert_image(train_data_ori, 'PQR', color_pca=color_pca, bias=bias)
            test_data, _,_ = data.convert_image(test_data_ori, 'PQR', color_pca=color_pca, bias=bias)
            if FLAGS.imgtype != 'PQR':
                if FLAGS.imgtype == 'P':
                    train_data = train_data[:,:,:,[0]]
                    test_data = test_data[:,:,:,[0]]
                elif FLAGS.imgtype == 'Q':
                    train_data = train_data[:,:,:,[1]]
                    test_data = test_data[:,:,:,[1]]
                elif FLAGS.imgtype == 'PQR_R':
                    train_data = train_data[:,:,:,[2]]
                    test_data = test_data[:,:,:,[2]]
        else:
            train_data = data.convert_image(train_data_ori,FLAGS.imgtype)
            test_data = data.convert_image(test_data_ori,FLAGS.imgtype)
    else:
        train_data = np.copy(train_data_ori)
        test_data = np.copy(test_data_ori)
        
    del train_data_ori, test_data_ori

    if FLAGS.normalization:
        train_data = data.Normalize(train_data, single=True)
        test_data = data.Normalize(test_data, single=True)
    
    train_data = train_data.astype('float64')
    test_data = test_data.astype('float64')

    #%%
    '''Saab Unsupervised Feature Extraction - Module - 1'''

    # -----------set parameters-----------
    # read data
    print(" > This is a test example: ")
    SaabArgs = [{'num_AC_kernels':-1, 'needBias':False, 'useDC':True, 'batch':None, 'cw': False, 'Lab': False}, 
                {'num_AC_kernels':-1, 'needBias':True, 'useDC':True, 'batch':None, 'cw': True},
                {'num_AC_kernels':-1, 'needBias':True, 'useDC':True, 'batch':None, 'cw': True},
                {'num_AC_kernels':-1, 'needBias':True, 'useDC':True, 'batch':None, 'cw': True},
                {'num_AC_kernels':-1, 'needBias':True, 'useDC':True, 'batch':None, 'cw': True},
                {'num_AC_kernels':-1, 'needBias':True, 'useDC':True, 'batch':None, 'cw': True},
                {'num_AC_kernels':-1, 'needBias':True, 'useDC':True, 'batch':None, 'cw': True},
                {'num_AC_kernels':-1, 'needBias':True, 'useDC':True, 'batch':None, 'cw': True}]
    
    shrinkArgs = [{'func':Shrink, 'win':5, 'stride': 1, 'pad':2, 'pool': 1}, 
                {'func': Shrink, 'win':5, 'stride': 1, 'pad':2, 'pool': 3},
                {'func': Shrink, 'win':3, 'stride': 1, 'pad':0, 'pool': 3},
                {'func': Shrink, 'win':3, 'stride': 1, 'pad':0, 'pool': 1}]
    concatArg = {'func':Concat}



    #%% pixelhop train
    start = time.time()
    # -----------Module-(1)-----------
    p2 = Pixelhop(depth = 4,
                   TH1 = 0.001,
                   TH2 = 0.0002,
                   SaabArgs = SaabArgs,
                   shrinkArgs = shrinkArgs,
                   concatArg = concatArg).fit(train_data[:50000])
    end = time.time()
    print(end - start)

    #%% get feature 
    start = time.time()
    save_feat(train_data, BS=BS, mode='tr', saveroot=saveroot, num_layers=4, output_all=True)
    save_feat(test_data, BS=BS, mode='te', saveroot=saveroot, num_layers=4, output_all=True)
    end = time.time()
    print(end - start)
        
