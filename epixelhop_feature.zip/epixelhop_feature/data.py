#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
#import keras
#from keras.datasets import mnist,cifar10
from os import listdir
from os.path import isfile, join
#import cv2
import saab_compact as saab
from scipy import ndimage
from skimage.color import rgb2lab,rgb2xyz,xyz2lab
import h5py
from skimage.transform import resize
import scipy.io as sio
from skimage.util.shape import view_as_windows

"""Load ImageNet May 1st 2019 Na Li"""
import skimage.io

def get_data_for_class(images, labels, cls):
	if type(cls)==list:
		idx=np.zeros(labels.shape, dtype=bool)
		for c in cls:
			idx=np.logical_or(idx, labels==c)
	else:
		idx=(labels==cls)
	return images[idx], labels[idx]

def collect_patches(samples, labels, SIZE, overlap):
    n, c, h, w= samples.shape
    output_h = (h -  SIZE) // (SIZE-overlap) + 1
    output_w = (w -  SIZE) // (SIZE-overlap) + 1
    # samples2=np.moveaxis(samples, 3, 1)
    patches=view_as_windows(samples, (1, c, SIZE, SIZE), step=(1, c, SIZE-overlap, SIZE-overlap))
    patches = patches.squeeze()
#    patches=patches.reshape(n*output_h*output_w, c, SIZE, SIZE)
    pat_labels = labels.repeat(output_h*output_w)
    return patches, pat_labels

def load_ImageNet(classNum = 1000,imgPerClassNum = 10,_root=None):

    train_images, train_labels, test_images, test_labels, class_list,class_label_list= [],[],[],[],[],[]
#    _root = ("/home/bingbing/Documents/PhD/Research/ImageNet/dataset/ImageNet10K/images")
    classNum = classNum
    imgPerClassNum = imgPerClassNum
    "adopt the last 2 images per class as test images"
    testNum = 0
    for i in range(classNum):
        _dir = ("%s/%d" % (_root, i))  # class 0~classNum
        for j in range(imgPerClassNum-testNum):
            _path = ("%s/img%d.jpg" % (_dir, j))  # img 0~imgPerClassNum
            im = read_and_preprocess(_path)
            train_images.append(im)
            train_labels.append(i)
        for j in range(testNum):
            _path = ("%s/img%d.jpg" % (_dir, imgPerClassNum-testNum-1))  # img 0~imgPerClassNum
            im = read_and_preprocess(_path)
            test_images.append(im)
            test_labels.append(i)

    _path_class = ("%s/wnids1000.txt" % (_root))
    i = 0 # class index
    with open(_path_class ) as fpClassDescriptor:
        for CLASS in fpClassDescriptor:
            i = i + 1
            if int( CLASS.split()[1] ) == i:
                class_list.append(int( CLASS.split()[1] ) )
                class_label_list.append(CLASS.split()[2])
            else:
                print ("Class list load ERROR! at Line %d"%i)
                
    return  np.array(train_images), np.array(train_labels), \
            np.array(test_images), np.array(test_labels), np.array(class_list),np.array(class_label_list)
   
def load_img_from_folder(_path):
    imfiles = [ f for f in listdir(_path) if isfile(join(_path,f))]
#    images = np.empty(len(onlyfiles), dtype=object)
    images=[]
    for n in range(0, len(imfiles)):
        im = skimage.io.imread(join(_path,imfiles[n]))
        images.append(im)
    return images

def load_mat_from_folder(_path,filename,objname):
#    images = np.empty(len(onlyfiles), dtype=object)
    images=[]
    for n in range(0, len(filename)):
        im = sio.loadmat(_path+filename[n][:-4]+'.mat')[objname]
        images.append(im)
    return images

         
def load_BSD(_root=None, mode=None):
    imPath = _root + '/images/'+ mode +'/'
    gtPath = _root + '/gtPNGbin/'+ mode +'/'
    imfiles = [ f for f in listdir(imPath) if isfile(join(imPath,f))]
    gtfiles = [ f for f in listdir(gtPath) if isfile(join(gtPath,f))]

#    images = np.empty(len(onlyfiles), dtype=object)
    images=[]
    gt = []
    shapes = []
    for n in range(0, len(imfiles)):
        im = skimage.io.imread(join(imPath,imfiles[n]))
        images.append(im)
        gt.append( skimage.io.imread(join(gtPath,gtfiles[n])))
        shapes.append(im.shape[0])
    return images, gt, imfiles

def load_BSD_matGT(_root=None, mode=None, gtmode='01'):
    imPath = _root + '/images/'+ mode +'/'
    if gtmode=='01':
        gtPath = _root + '/gtMAT_01/'+ mode +'/'
    elif gtmode=='count':
        gtPath = _root + '/gtMAT_count/'+ mode +'/'
    imfiles = [ f for f in listdir(imPath) if isfile(join(imPath,f))]

#    images = np.empty(len(onlyfiles), dtype=object)
    images=[]
    gt = []
    shapes = []
    for n in range(0, len(imfiles)):
        im = skimage.io.imread(join(imPath,imfiles[n]))
        images.append(im)
        temp = sio.loadmat(gtPath+imfiles[n][:-4]+'.mat')
        gt.append(temp['gt'])
        shapes.append(im.shape[0])
    return images, gt, imfiles

def load_se_matGT(_root=None, mode=None, gtmode='01'):
    imPath = _root + '/images/se/'+ mode +'/'
    if gtmode=='01':
        gtPath = _root + '/gtMAT_01/'+ mode +'/'
    elif gtmode=='count':
        gtPath = _root + '/gtMAT_count/'+ mode +'/'
    imfiles = [ f for f in listdir(imPath) if isfile(join(imPath,f))]

#    images = np.empty(len(onlyfiles), dtype=object)
    images=[]
    gt = []
    shapes = []
    for n in range(0, len(imfiles)):
        im = skimage.io.imread(join(imPath,imfiles[n]))
        images.append(im)
        temp = sio.loadmat(gtPath+imfiles[n][:-4]+'.mat')
        gt.append(temp['gt'])
        shapes.append(im.shape[0])
    return images, gt, imfiles


def import_data2(name,use_classes=0,root=None,gtmode='01'):
    # return (n, height, width, channel)
    if name=="BSD500":
        (train_images, train_gt, train_name) = load_BSD_matGT(_root=root,mode='train', gtmode = gtmode)
        (val_images, val_gt, val_name) = load_BSD_matGT(_root=root,mode='val', gtmode = gtmode)
        (test_images, test_gt, test_name) = load_BSD_matGT(_root=root,mode='test', gtmode = gtmode)
        
#        train_images = train_images/255.
#        
#        test_images = test_images/255.
        
        return train_images, train_gt, val_images, val_gt, test_images, test_gt, train_name, val_name, test_name
    elif name=="se":
        (train_images, train_gt, train_name) = load_se_matGT(_root=root,mode='train', gtmode = gtmode)
        (val_images, val_gt, val_name) = load_se_matGT(_root=root,mode='val', gtmode = gtmode)
        (test_images, test_gt, test_name) = load_se_matGT(_root=root,mode='test', gtmode = gtmode)
        
#        train_images = train_images/255.
#        
#        test_images = test_images/255.
        
        return train_images, train_gt, val_images, val_gt, test_images, test_gt, train_name, val_name, test_name
    else:
        if name=="mnist":
            (train_images, train_labels), (test_images, test_labels) = mnist.load_data()
            print (train_labels.shape)
            train_images=train_images/255.
            test_images=test_images/255.
            
            ##train_images = resize(train_images, (train_images.shape[0],16,16))
            ##test_images = resize(test_images, (test_images.shape[0],16,16))
    
            # print(train_images.shape) # 60000*28*28
        elif name=="usps":
            with h5py.File("./usps.h5", 'r') as hf:
                train = hf.get('train')
                train_images = train.get('data')[:]
                # print train_images[0]
                train_labels = train.get('target')[:]
                test = hf.get('test')
                test_images = test.get('data')[:]
                test_labels = test.get('target')[:]
                train_images = train_images.reshape((-1,16,16))
                test_images = test_images.reshape((-1,16,16))
                # print(train_images.shape, train_labels.shape, test_images.shape, test_labels.shape)
        elif name =="svhn":
            mat = sio.loadmat('svhn_train_32x32.mat')
            train_images = mat['X']
            train_images = np.moveaxis(train_images,3,0)
            train_labels = mat['y'].squeeze()
            print (train_labels)
            mat = sio.loadmat('svhn_test_32x32.mat')
            test_images = mat['X']
            test_images = np.moveaxis(test_images,3,0)
            test_labels = mat['y'].squeeze()
            # change 0's label from 10 to 0
            for i in xrange(train_labels.shape[0]):
                if train_labels[i] == 10:
                    train_labels[i] = 0
            for i in xrange(test_labels.shape[0]):
                if test_labels[i] == 10:
                    test_labels[i] = 0
    
            # convert to LAB
            train_images = convert_image(train_images,"LAB")
            test_images = convert_image(test_images,"LAB")
            train_images = train_images[:,:,:,0]
            test_images = test_images[:,:,:,0]
    
            train_images = resize(train_images, (train_images.shape[0],16,16))
            test_images = resize(test_images, (test_images.shape[0],16,16))
    
        elif name == "cifar10_L":
            (train_images, train_labels), (test_images, test_labels) = cifar10.load_data()
            train_images = convert_image(train_images,"LAB")
            test_images = convert_image(test_images,"LAB")
            train_images = train_images[:,:,:,0]
            test_images = test_images[:,:,:,0]
    
            train_labels = train_labels.squeeze()
            test_labels = test_labels.squeeze()
    
        # print(train_images.shape)
        class_list=[0,1,2,3,4,5,6,7,8,9]
        class_label_list = []
        """
        Load Imagenet from local storage
        """
        if name == "ImageNet":
            (train_images, train_labels, test_images, test_labels, class_list, class_label_list)=load_ImageNet(classNum=1000, imgPerClassNum=10, _root=root)
            train_images = train_images/255.
            test_images = test_images/255.
        if len(train_images.shape) == 3:
            train_images = train_images.reshape((train_images.shape[0], train_images.shape[1], train_images.shape[2], 1))
            test_images = test_images.reshape((test_images.shape[0], test_images.shape[1], test_images.shape[2], 1))
    
        return train_images, train_labels, test_images, test_labels, class_list,class_label_list


def load_(path):
    data = torchvision.datasets.ImageFolder(path,transform=transforms.Compose([transforms.ToTensor(),]))
    loader = torch.utils.data.DataLoader(data, batch_size=1, shuffle=False, **kwargs)
    return loader

def create_numpy_dataset(loader=None):
    dataset = []
    labels = []
    for data in loader:
        data_numpy = data[0].numpy()
        label_numpy = data[1].numpy()
        dataset.append(data_numpy.squeeze())
        labels.append(label_numpy)
    dataset = np.array(dataset)
    labels = np.array(labels).squeeze()
    print("Numpy testing dataset shape is {}".format(dataset.shape))
    print("Numpy testing labels shape is {}".format(labels.shape))
    # return datasets
    return dataset, labels

def import_local_data(root):
    loader=load_(root) 
    train_images, train_labels = create_numpy_dataset(loader)
    return train_images, train_labels



def import_data(use_classes):
	(train_images, train_labels), (test_images, test_labels) = cifar10.load_data()
	train_images=train_images/255.
	test_images=test_images/255.
	# print(train_images.shape) # 50000*32*32*3

	if use_classes!='0-9':
		class_list=saab.parse_list_string(use_classes)
		train_images, train_labels=get_data_for_class(train_images, train_labels, class_list)
		test_images, test_labels=get_data_for_class(test_images, test_labels, class_list)
		# print(class_list)
	else:
		class_list=[0,1,2,3,4,5,6,7,8,9]
		
	return train_images, train_labels, test_images, test_labels, class_list


def rgb2ycbcr(im):
    xform = np.array([[.299, .587, .114], [-.1687, -.3313, .5], [.5, -.4187, -.0813]])
    ycbcr = im.dot(xform.T)
    ycbcr[:,:,[1,2]] += 128
    return np.uint8(ycbcr)

def rgb2cielab(im):
    h,w,c = im.shape
    rgb = np.moveaxis(im.reshape(-1,3),-1,0)
    def func(t):
        if (t > 0.008856):
            return np.power(t, 1/3.0);
        else:
            return 7.787 * t + 16 / 116.0;
    
    #Conversion Matrix
    matrix = [[0.412453, 0.357580, 0.180423],
              [0.212671, 0.715160, 0.072169],
              [0.019334, 0.119193, 0.950227]]
    
    cie = np.dot(matrix, rgb);
    
    cie[0] = cie[0] /0.950456;
    cie[2] = cie[2] /1.088754; 
    
    # Calculate the L
    L = 116 * np.power(cie[1], 1/3.0) - 16.0 if cie[1] > 0.008856 else 903.3 * cie[1];
    
    # Calculate the a 
    a = 500*(func(cie[0]) - func(cie[1]));
    
    # Calculate the b
    b = 200*(func(cie[1]) - func(cie[2]));
    
    #  Values lie between -128 < b <= 127, -128 < a <= 127, 0 <= L <= 100 
    return [L,a,b]


def convert_image(data,forma, color_pca=None, bias=None):
    if data.shape[1] < 5:
        data=np.moveaxis(data, 1,3)
    if forma == 'YCbCr' or forma == 'LAB' or forma == 'cieLAB' or forma=='PQR' or forma=='PQR_abs':
        new_data = np.zeros((data.shape))
        from sklearn.decomposition import PCA
    elif forma == 'AB' or forma == 'cieAB' or forma == 'CbCr':
        new_data = np.zeros((data.shape[0],data.shape[1],data.shape[2],2))
    else:
        new_data = np.zeros((data.shape[0],data.shape[1],data.shape[2]))
        
    if forma=='PQR':
        if color_pca is None:
            color_pca = PCA(n_components=3,svd_solver='full').fit(data.reshape(-1,3))
        tmp = color_pca.transform(data.reshape(-1,3)).reshape(new_data.shape)
        if bias is None:
            bias = -1*np.min(tmp) # shift up the negative values
        # bias = np.min(tmp.reshape(-1,3),axis=0,keepdims=1)
        new_data = tmp + bias
        # new_data[i] = pca.transform(data[i].reshape(-1,3)).reshape(new_data[i].shape)
        return new_data, color_pca, bias

    else:
        for i in range(data.shape[0]):
            im_ycbcr = rgb2ycbcr(data[i]*255.)/255.
    #        im_ciexyz = rgb2xyz(data[i]*255.)
    #        im_cielab = xyz2lab(im_ciexyz)
    #        im_cielab = rgb2cielab(data[i]*255.)
            if forma == 'YCbCr':
                new_data[i] = im_ycbcr
    #            temp = np.concatenate((im_ycbcr[:,:,:1],Normalize(im_ycbcr[:,:,1:2] , ABS=False)),2)
    #            new_data[i] = np.concatenate((temp,Normalize(im_ycbcr[:,:,2:3] , ABS=False)),2)
            elif forma == 'LAB':
                new_data[i] = Normalize(rgb2lab(data[i]), ABS=False)  
            elif forma == 'AB':
                new_data[i] = Normalize(rgb2lab(data[i])[:,:,1:], ABS=True)     
            elif forma == 'L':
                new_data[i] = Normalize(rgb2lab(data[i])[:,:,0], ABS=False)
            elif forma == 'AL':
                new_data[i] = Normalize(rgb2lab(data[i])[:,:,1], ABS=False)
            elif forma == 'BL':
                new_data[i] = Normalize(rgb2lab(data[i])[:,:,2], ABS=True)     
    #        elif forma == 'cieLAB':
    #            new_data[i] = Normalize(im_cielab, ABS=False)  
    #        elif forma == 'cieL':   
    #            new_data[i] = Normalize(im_cielab[:,:,0], ABS=False)         
    #        elif forma == 'cieA':   
    #            new_data[i] = Normalize(im_cielab[:,:,1], ABS=False)              
    #        elif forma == 'cieB':   
    #            new_data[i] = Normalize(im_cielab[:,:,2], ABS=False)              
            elif forma == 'R':
                new_data[i] = data[i,:,:,0]
            elif forma == 'G':
                new_data[i] = data[i,:,:,1]
            elif forma == 'B':
                new_data[i] = data[i,:,:,2]
            elif forma == 'Y':
                new_data[i] = im_ycbcr[:,:,0]
            elif forma == 'Cb':
                new_data[i] = Normalize(im_ycbcr[:,:,1] , ABS=False)           
            elif forma == 'Cr':
                new_data[i] = Normalize(im_ycbcr[:,:,2] , ABS=False)  
            elif forma == 'CbCr':
                new_data[i] = Normalize(im_ycbcr[:,:,1:] , ABS=False)  
            elif forma == 'Gray':
                new_data[i] = 0.2989 * data[i,:,:,0] + 0.5870 * data[i,:,:,1] + 0.1140 * data[i,:,:,2]
            # elif forma=='PQR':
            #     pca = PCA(n_components=3,svd_solver='full').fit(data[i].reshape(-1,3))
            #     tmp = pca.transform(data[i].reshape(-1,3)).reshape(new_data[i].shape)
            #     bias = -1*np.min(tmp) # shift up the negative values
            #     # bias = np.min(tmp.reshape(-1,3),axis=0,keepdims=1)
            #     new_data[i] = tmp + bias
            #     # new_data[i] = pca.transform(data[i].reshape(-1,3)).reshape(new_data[i].shape)
            elif forma=='PQR_abs':
                pca = PCA(n_components=3,svd_solver='full').fit(data[i].reshape(-1,3))
                new_data[i] = np.abs(pca.transform(data[i].reshape(-1,3)).reshape(new_data[i].shape))
                
        if np.array(new_data.shape).size<4:
            new_data = new_data[:,:,:,np.newaxis]
    #    new_data = np.moveaxis(new_data,3,1)
        return new_data
#    return np.moveaxis(new_data,3,1)

def Normalize(data, ABS=False, single=False):
    # if ABS:
    #     data_new = np.abs(data)
    # else:
    #     data_new = data
    if single == False:
        data_new = data - data.min()
        return data_new/(data_new.max()+1e-5)
    elif single==True:
        data_new = np.zeros((data.shape))
        for n in range(data.shape[0]):
            data_new[n] = data[n] - data[n].min()
            data_new[n] = data_new[n]/(data_new[n].max()+1e-5)
        return data_new
   
def transform_data(data,TYPE):
    print('transform data:', TYPE)  
    L3 = np.array([1, 2, 1]).reshape(3,1)
    S3 = np.array([1, -2, 1]).reshape(3,1)
    E3 = np.array([1, 0, -1]).reshape(3,1)
    L3L3 = np.dot(L3,L3.transpose())
    E3E3 = np.dot(E3,E3.transpose())
    S3S3 = np.dot(S3,S3.transpose())
    L3E3 = np.dot(L3,E3.transpose())
    L3S3 = np.dot(L3,S3.transpose())
    E3L3 = np.dot(E3,L3.transpose())
    E3S3 = np.dot(E3,S3.transpose())
    S3L3 = np.dot(S3,L3.transpose())
    S3E3 = np.dot(S3,E3.transpose())
#    kx = np.array([[1,0,-1],[1,0,-1],[1,0,-1]])
#    ky = np.array([[1,1,1] ,[0,0,0], [-1,-1,-1]])
    kxy = np.array([[-2,-1,0],[-1,0,1],[0,1,2]])
    kyx = np.array([[0,-1,-2],[1,0,-1],[2,1,0]])
    if TYPE=='sxsy':
        transformed_data = np.zeros((data.shape[0],data.shape[1],data.shape[2],2))
    else:
        transformed_data = np.zeros(data.shape)
    for i in range(data.shape[0]):
        img = data[i,:,:,0]
        # Get x-gradient in "sx"
        if TYPE == 'sx':
            transformed_data[i,:,:,0] = Normalize(ndimage.sobel(img,axis=0,mode='reflect'))
        # Get y-gradient in "sy"
        if TYPE == 'sy':
            transformed_data[i,:,:,0] = Normalize(ndimage.sobel(img,axis=1,mode='reflect'))
        if TYPE == 'sxsy':
            transformed_data[i,:,:,0] = Normalize(ndimage.sobel(img,axis=0,mode='reflect'))
            transformed_data[i,:,:,1] = Normalize(ndimage.sobel(img,axis=1,mode='reflect'))            
        if TYPE == 'xy':
            transformed_data[i,:,:,0] = Normalize(ndimage.convolve(img,kxy,mode='reflect'))
        # Get y-gradient in "sy"
        if TYPE == 'yx':
            transformed_data[i,:,:,0] = Normalize(ndimage.convolve(img,kyx,mode='reflect'))
        if TYPE == 'sxy':
            sx = ndimage.sobel(img,axis=0,mode='reflect')
            sy = ndimage.sobel(img,axis=1,mode='reflect')
        # Get square root of sum of squares
            transformed_data[i,:,:,0] = Normalize(np.hypot(sx,sy))
        # Hopefully see some edges
        if TYPE == 'lp':
            transformed_data[i,:,:,0]=Normalize(ndimage.laplace(img,mode='reflect'))
        # LAWS
        if TYPE == 'l3l3':
            transformed_data[i,:,:,0]=Normalize(ndimage.convolve(img,L3L3,mode='reflect'), ABS=False)
        if TYPE == 'e3e3':
            transformed_data[i,:,:,0]=Normalize(ndimage.convolve(img,E3E3,mode='reflect'), ABS=False)
        if TYPE == 's3s3':
            transformed_data[i,:,:,0]=Normalize(ndimage.convolve(img,S3S3,mode='reflect'), ABS=False)
        if TYPE == 'l3e3':
            transformed_data[i,:,:,0]=Normalize(ndimage.convolve(img,L3E3,mode='reflect'), ABS=False)
        if TYPE == 'l3s3':
            transformed_data[i,:,:,0]=Normalize(ndimage.convolve(img,L3S3,mode='reflect'), ABS=False)
        if TYPE == 'e3l3':
            transformed_data[i,:,:,0]=Normalize(ndimage.convolve(img,E3L3,mode='reflect'), ABS=False)
        if TYPE == 'e3s3':
            transformed_data[i,:,:,0]=Normalize(ndimage.convolve(img,E3S3,mode='reflect'), ABS=False)
        if TYPE == 's3l3':
            transformed_data[i,:,:,0]=Normalize(ndimage.convolve(img,S3L3,mode='reflect'), ABS=False)
        if TYPE == 's3e3':
            transformed_data[i,:,:,0]=Normalize(ndimage.convolve(img,S3E3,mode='reflect'), ABS=False)
    return transformed_data
"""

"""

def read_and_preprocess(im_path):
    im = skimage.io.imread(im_path)
    #im = skimage.color.rgb2gray(im)
    #im = skimage.transform.resize(im, (256, 256))
    return im
